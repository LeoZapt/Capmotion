package com.acmesoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcmeSoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
