package com.acmesoft.Repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.repository.CrudRepository;

import com.acmesoft.Entity.Persona;

public interface PersonaRepositorio extends CrudRepository<Persona, Long>
{
	@Transactional
	Persona  findByCuenta(String cuenta);
}
