package com.acmesoft.Repository;

import javax.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.repository.CrudRepository;

import com.acmesoft.Entity.Historial;

public interface HistorialRepositorio extends CrudRepository<Historial, Long>
{
	@Transactional
	List<Historial> findByIdPersona(Long idPersona);
}
