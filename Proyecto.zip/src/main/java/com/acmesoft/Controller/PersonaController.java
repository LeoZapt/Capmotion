package com.acmesoft.Controller;

import java.io.Console;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acmesoft.Entity.Persona;
import com.acmesoft.Entity.Historial;
import com.acmesoft.Repository.HistorialRepositorio;
import com.acmesoft.Repository.PersonaRepositorio;

@Controller
public class PersonaController 
{
	@Autowired
	PersonaRepositorio repositorio;
	
	@Autowired
	HistorialRepositorio historial;
	
	@GetMapping({"/","/login"})
	public String login() {
		return "login";
	}
	@GetMapping({"/admin"})
	public String admin(Model modelo, Persona persona) {
		modelo.addAttribute("persona", new Persona());
		modelo.addAttribute("personas",repositorio.findAll());
		modelo.addAttribute("historials",historial.findAll());
		return "admin";
	}
	
	@PostMapping("/admin")
	public String index(Model modelo, Persona persona)
	{
		modelo.addAttribute("persona", new Persona());
		modelo.addAttribute("personas",repositorio.findAll());
		modelo.addAttribute("historials",historial.findAll());
		return "admin";
	}
	
	@GetMapping("/editarPersona/{id}")
	public String editarPersonaForm(Model modelo, @PathVariable(name="id") Long id)
	{
		Persona personaEditar = repositorio.findById(id).get();
		modelo.addAttribute("persona", personaEditar);
		modelo.addAttribute("personas",repositorio.findAll());
		modelo.addAttribute("historialPersonas", historial.findByIdPersona(id));
		return "persona";
	}
	
	@GetMapping("/eliminarPersona/{id}")
	public String eliminarPersonaForm(Model modelo, @PathVariable(name="id") Long id)
	{
		Persona personaEliminar = repositorio.findById(id).get();
		repositorio.delete(personaEliminar);
		modelo.addAttribute("persona", new Persona());
		modelo.addAttribute("personas",repositorio.findAll());
		modelo.addAttribute("historials",historial.findAll());
		return "admin";
	}
	
	@GetMapping("/consignarPersona/{id}/{saldo}")
	public String consignarPersonaForm(Model modelo, @PathVariable(name="id") Long id, @PathVariable(name="saldo") Long saldo)
	{
		saldo= Math.abs(saldo);
		Persona personaEditar = repositorio.findById(id).get();
		Long dineroConsignar = personaEditar.getSaldo() + saldo;
		personaEditar.setSaldo(dineroConsignar);
		repositorio.save(personaEditar);
		modelo.addAttribute("persona", personaEditar);
		modelo.addAttribute("personas",repositorio.findAll());
		
		// Colocando movimiento en historial
		Historial historialPersona = new Historial();
		historialPersona.setIdPersona(id);
		historialPersona.setMovimiento("Consignación");
		historialPersona.setValor(saldo);
		historial.save(historialPersona);
		modelo.addAttribute("historial", historialPersona);
		modelo.addAttribute("historials",historial.findAll());
		modelo.addAttribute("historialPersona", historialPersona);
		modelo.addAttribute("historialPersonas", historial.findByIdPersona(id));
		return "persona";
	}
	
	@GetMapping("/retirarPersona/{id}/{saldo}")
	public String retirarPersonaForm(Model modelo, @PathVariable(name="id") Long id, @PathVariable(name="saldo") Long saldo, RedirectAttributes atributo)
	{
		saldo = Math.abs(saldo);
		Persona personaEditar = repositorio.findById(id).get();
		if(saldo > personaEditar.getSaldo())
		{
			modelo.addAttribute("noexitoso", "Excede el saldo actual");
		}
		else 
		{
			Long dineroConsignar = personaEditar.getSaldo() - saldo;
			personaEditar.setSaldo(dineroConsignar);
			repositorio.save(personaEditar);
			
			// Colocando movimiento en historial
			Historial historialPersona = new Historial();
			historialPersona.setIdPersona(id);
			historialPersona.setMovimiento("Retiro");
			historialPersona.setValor(saldo);
			historial.save(historialPersona);
			modelo.addAttribute("historial", historialPersona);
			modelo.addAttribute("historials",historial.findAll());
			modelo.addAttribute("historialPersonas",historial.findByIdPersona(id));
		}
		modelo.addAttribute("persona", personaEditar);
		modelo.addAttribute("personas",repositorio.findAll());
		return "persona";
	}
	
	@GetMapping("/transferirPersona/{id}/{idTransferir}/{valor}")
	public String transferirPersonaForm(Model modelo, @PathVariable(name="id") Long id, @PathVariable(name="idTransferir") String idTransferir,
				@PathVariable(name="valor") Long valor, RedirectAttributes atributo)
	{
		valor = Math.abs(valor);
		// validar que exista la cuenta a transferir
		Persona existePersona = repositorio.findByCuenta(idTransferir);
		if (existePersona != null)
		{		
			// Persona a descontar la transferencia
			Persona personaRestar= repositorio.findById(id).get();
			if(valor > personaRestar.getSaldo())
			{
				modelo.addAttribute("noexitoso", "Excede el saldo actual");
			}
			else 
			{
				Long dineroConsignar = personaRestar.getSaldo() - valor;
				personaRestar.setSaldo(dineroConsignar);
				repositorio.save(personaRestar);
			}
			// Persona a consignar transferencia	
			Long idPersona = existePersona.getId();
			Persona personaSumar = repositorio.findById(idPersona).get();
			Long valorConsignar = personaSumar.getSaldo() + valor;
			personaSumar.setSaldo(valorConsignar);
			repositorio.save(personaSumar);
			modelo.addAttribute("persona", personaSumar);
			modelo.addAttribute("persona", personaRestar);		
			modelo.addAttribute("personas",repositorio.findAll());
			
			// Colocando movimiento en historial
			Historial historialPersona = new Historial();
			historialPersona.setIdPersona(id);
			historialPersona.setMovimiento("Transferencia a " + personaSumar.getCuenta());
			historialPersona.setValor(valor);
			historial.save(historialPersona);
			modelo.addAttribute("historial", historialPersona);
			modelo.addAttribute("historials",historial.findAll());
			modelo.addAttribute("historialPersonas",historial.findByIdPersona(id));
		}
		else
		{
			modelo.addAttribute("noexitoso", "Cuenta a transferir no existe");
		}
		return "persona";
	}
	
	@PostMapping("/crearPersona")
	public String crearPersona(Model modelo, Persona persona)
	{
		repositorio.save(persona);
		modelo.addAttribute("persona", new Persona());
		modelo.addAttribute("personas",repositorio.findAll());
		modelo.addAttribute("historials",historial.findAll());
		return "admin";
	}
	
}
