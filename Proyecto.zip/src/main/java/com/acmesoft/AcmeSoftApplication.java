package com.acmesoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcmeSoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcmeSoftApplication.class, args);
	}

}
