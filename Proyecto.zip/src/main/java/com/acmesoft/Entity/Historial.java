package com.acmesoft.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
@Table(name="tbl_historial")

public class Historial 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long idTransferencia;
	private Long idPersona;	
	private String movimiento;
	private Long valor;
	
	public Historial()
	{
		
	}
	
	public Historial(Long idTransferencia, Long idPersona, String movimiento, Long valor) 
	{
		super();
		this.idTransferencia = idTransferencia;
		this.idPersona = idPersona;
		this.movimiento = movimiento;
		this.valor = valor;
	}

	public Long getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(Long idPersona) {
		this.idPersona = idPersona;
	}

	public Long getIdTransferencia() {
		return idTransferencia;
	}

	public void setIdTransferencia(Long idTransferencia) {
		this.idTransferencia = idTransferencia;
	}

	public String getMovimiento() {
		return movimiento;
	}

	public void setMovimiento(String movimiento) {
		this.movimiento = movimiento;
	}

	public Long getValor() {
		return valor;
	}

	public void setValor(Long saldo) {
		this.valor = saldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idTransferencia == null) ? 0 : idTransferencia.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Historial other = (Historial) obj;
		if (idTransferencia != other.idTransferencia)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Historial [idTransferencia=" + idTransferencia + ", idPersona="+ idPersona +",movimiento=" + movimiento + ", valor=" + valor + "]";
	}
	
	
	
}
