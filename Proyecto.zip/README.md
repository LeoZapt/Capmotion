AcmeSoft PROJECT
This project was created to develop a solution for a ATM application.

Getting Started
Make sure you have the Angular CLI installed globally.

Clone the repository
git clone https://github.com/Juanca182/bookstore
cd bookstore
After cloning the repo, navigate to it and start the needed packages installation.

Install npm packages
   npm install
After the packages installation, run ng serve and then navigate to http://localhost:4200/. The app will be running.